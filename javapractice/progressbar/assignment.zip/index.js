document.addEventListener('DOMContentLoaded', () => {
  console.log('It works');
});