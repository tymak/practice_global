'use strict';

console.log('It works!');